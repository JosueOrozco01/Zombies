public interface IPersistible
{
    void GuardarEstado();
    void CargarEstado();
}
